class PrintName {

    public static void main(String[] args){
        String name = "JAVA";
        printNameAsStars(name); 
    }
    public static void printNameAsStars(String name){
        //J,A,V,A.
        //J
        System.out.println("*******");
        System.out.println("*");
        System.out.println("*");
        System.out.println("*");
        System.out.println("******");
        System.out.println("*");
        System.out.println("*");
        System.out.println("*");
        System.out.println("******");
        System.out.println();
        
        //A
        System.out.println("***");
        System.out.println("**");
        System.out.println("**");
        System.out.println("**");
        System.out.println("******");
        System.out.println("**");
        System.out.println("**");
        System.out.println();//
        
        //V
        System.out.print("**");
        System.out.println("**");
        System.out.println("**");
        System.out.println("**");
        System.out.println("**");
        System.out.println();//
        
        //A
        System.out.println("***");
        System.out.println("**");
        System.out.println("**");
        System.out.println("**");
        System.out.println("*******");
        System.out.println("**");
        System.out.println("**");
    }
}     
        
        
 